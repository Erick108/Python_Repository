from django.db import models

class Producto(models.Model):
    codigo = models.CharField(10)
    nombre = models.CharField(50)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.IntegerField()

def __str__(self):
    return f"Nombre del producto: {self.nombre}"