from django.shortcuts import render

def home(request):
    return render(request,'home.html')

def ver_productos(request):
    return render(request, 'verproductos.html')

def crear_producto(request):
    if request.method == "POST":
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse("Producto ingresado correctamente")
        else:
            form = ProductioForm()
            return render (request, "crear_producto.html", {"form":form})
